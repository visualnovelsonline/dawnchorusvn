Disconnected = 0
SentHandshake = 1
AwaitingResponse = 2
Connected = 3
